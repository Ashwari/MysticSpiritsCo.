﻿using Microsoft.AspNetCore.Mvc;
using MysticSpiritsCoUpdated.Models;
using NuGet.Protocol.Plugins;
using System.Data.SqlClient;

namespace MysticSpiritsCoUpdated.Controllers
{
    public class BookingController : Controller
    {
        public string connection = "Data Source=Ashwari\\SqlExpress;Initial Catalog=MysticSpiritsDatabase;Integrated Security=True;Encrypt=True;TrustServerCertificate=True";

        [HttpGet]
        public IActionResult Bookings()
        {
            return View();

        }
        [HttpPost]
        public IActionResult Bookings(BookingModel BM)
        {
            if (ModelState.IsValid)
            {
                using (SqlConnection con = new SqlConnection(connection))
                {
                    con.Open();

                    // Check if there's an existing booking for the same experience, date, and time
                    string checkDuplicateQuery = "SELECT COUNT(*) FROM Bookings WHERE BookingExperience = @BookingExperience AND BookingDate = @BookingDate AND BookingTime = @BookingTime";
                    using (SqlCommand checkCmd = new SqlCommand(checkDuplicateQuery, con))
                    {
                        checkCmd.Parameters.AddWithValue("@BookingExperience", BM.BookingExperience);
                        checkCmd.Parameters.AddWithValue("@BookingDate", BM.BookingDate.Date);
                        checkCmd.Parameters.AddWithValue("@BookingTime", BM.BookingTime);

                        int existingBookingsCount = (int)checkCmd.ExecuteScalar();
                        if (existingBookingsCount > 0)
                        {
                            TempData["ErrorMessage"] = "A booking for the selected experience, date, and time already exists. Please choose a different time slot.";
                            return View(BM);
                        }
                    }

                    // If no duplicate booking found, proceed with insertion
                    string insertQuery = "INSERT INTO Bookings VALUES(@Username, @Email, @PhoneNumber, @BookingExperience, @NumberOfGuests, @BookingDate, @BookingTime)";
                    using (SqlCommand cmd = new SqlCommand(insertQuery, con))
                    {
                        cmd.Parameters.AddWithValue("@Username", BM.Username);
                        cmd.Parameters.AddWithValue("@Email", BM.Email);
                        cmd.Parameters.AddWithValue("@PhoneNumber", BM.PhoneNumber);
                        cmd.Parameters.AddWithValue("@BookingExperience", BM.BookingExperience);
                        cmd.Parameters.AddWithValue("@NumberOfGuests", BM.NumberOfGuests);
                        cmd.Parameters.AddWithValue("@BookingDate", BM.BookingDate.Date);
                        cmd.Parameters.AddWithValue("@BookingTime", BM.BookingTime);

                        cmd.ExecuteNonQuery();

                        TempData["SuccessMessage"] = "Booking Created Successfully";
                        ModelState.Clear();
                    }
                }

                // If the form submission was successful, return the "thanks" view
                return RedirectToAction("Thanks", "Booking");
            }

            // If the form submission failed, return the same view with the model
            return View(BM);
        }

        public IActionResult Thanks()
        {
            return View();

        }
    }
}
