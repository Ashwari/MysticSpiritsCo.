﻿using Microsoft.AspNetCore.Mvc;
using MysticSpiritsCoUpdated.Models;
using System.Data.SqlClient;

namespace MysticSpiritsCoUpdated.Controllers
{
    public class AdminController : Controller
    {
        public string connection = "Data Source=Ashwari\\SqlExpress;Initial Catalog=MysticSpiritsDatabase;Integrated Security=True;Encrypt=True;TrustServerCertificate=True";

        public IActionResult GinMaking(BookingDisplayModel booking)
        {
            SqlConnection con = new SqlConnection(connection);
            string query = "SELECT * FROM Bookings WHERE BookingExperience = 'Gin Making'";
            SqlCommand com = new SqlCommand(query);
            com.Connection = con;
            con.Open();
            SqlDataReader sdr = com.ExecuteReader();
            List<BookingDisplayModel> objmodel = new List<BookingDisplayModel>();

            if (sdr.HasRows)
            {
                while (sdr.Read())
                {
                    var details = new BookingDisplayModel();
                    details.Booking_ID = (int)sdr["Booking_ID"];
                    details.Username = sdr["Username"].ToString();
                    details.Email = sdr["Email"].ToString();
                    details.PhoneNumber = sdr["PhoneNumber"].ToString();
                    details.BookingExperience = sdr["BookingExperience"].ToString();
                    details.NumberOfGuests = sdr["NumberOfGuests"].ToString();
                    details.BookingDate = DateTime.Parse(sdr["BookingDate"].ToString());
                    details.BookingTime = TimeSpan.Parse(sdr["BookingTime"].ToString());
                    objmodel.Add(details);
                }
                booking.UserBookings = objmodel;
                con.Close();
            }
            return View("GinMaking", objmodel);
        }
        public IActionResult GinTasting(BookingDisplayModel booking)
        {
            SqlConnection con = new SqlConnection(connection);
            string query = "SELECT * FROM Bookings WHERE BookingExperience = 'Gin Tasting'";
            SqlCommand com = new SqlCommand(query);
            com.Connection = con;
            con.Open();
            SqlDataReader sdr = com.ExecuteReader();
            List<BookingDisplayModel> objmodel = new List<BookingDisplayModel>();

            if (sdr.HasRows)
            {
                while (sdr.Read())
                {
                    var details = new BookingDisplayModel();
                    details.Booking_ID = (int)sdr["Booking_ID"];
                    details.Username = sdr["Username"].ToString();
                    details.Email = sdr["Email"].ToString();
                    details.PhoneNumber = sdr["PhoneNumber"].ToString();
                    details.BookingExperience = sdr["BookingExperience"].ToString();
                    details.NumberOfGuests = sdr["NumberOfGuests"].ToString();
                    details.BookingDate = DateTime.Parse(sdr["BookingDate"].ToString());
                    details.BookingTime = TimeSpan.Parse(sdr["BookingTime"].ToString());
                    objmodel.Add(details);
                }
                booking.UserBookings = objmodel;
                con.Close();
            }
            return View("GinTasting", objmodel);
        }

        public IActionResult DeleteGM(int id)
        {
            using (SqlConnection con = new SqlConnection(connection))
            {
                con.Open();
                string query = "DELETE FROM Bookings WHERE Booking_ID = @Booking_ID AND BookingExperience = 'Gin Making'";
                SqlCommand com = new SqlCommand(query, con);
                com.Parameters.AddWithValue("@Booking_ID", id);
                com.ExecuteNonQuery();
            }
            return RedirectToAction("GinMaking");
        }

        public IActionResult DeleteGT(int id)
        {
            using (SqlConnection con = new SqlConnection(connection))
            {
                con.Open();
                string query = "DELETE FROM Bookings WHERE Booking_ID = @Booking_ID AND BookingExperience = 'Gin Tasting'";
                SqlCommand com = new SqlCommand(query, con);
                com.Parameters.AddWithValue("@Booking_ID", id);
                com.ExecuteNonQuery();
            }
            return RedirectToAction("GinTasting");
        }
    }
}
