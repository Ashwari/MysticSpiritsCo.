﻿using Microsoft.AspNetCore.Mvc;
using MysticSpiritsCoUpdated.Models;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.Text;

namespace MysticSpiritsCoUpdated.Controllers
{
    public class AccountController : Controller
    {
        public string connection = "Data Source=Ashwari\\SqlExpress;Initial Catalog=MysticSpiritsDatabase;Integrated Security=True;Encrypt=True;TrustServerCertificate=True";

        [HttpGet]
        public ActionResult SignUp()
        {
            return View();
        }
        [HttpPost]
        public ActionResult SignUp(UserModel um)
        {
            if (ModelState.IsValid)
            {
                UserModel user = new UserModel();
                using (SqlConnection con = new SqlConnection(connection))
                {
                    con.Open();
                    string hashedPassword = HashPassword(um.Password);

                    string SqlQuery = "INSERT INTO Users VALUES(@Username, @Email, @Password)";
                    using (SqlCommand cmd = new SqlCommand(SqlQuery, con))
                    {
                        cmd.Parameters.AddWithValue("@Username", um.Username);
                        cmd.Parameters.AddWithValue("@Email", um.Email);
                        cmd.Parameters.AddWithValue("@Password", hashedPassword);
                        ModelState.Clear();
                        ViewData["result"] = cmd.ExecuteNonQuery();
                        con.Close();
                        TempData["AlertMessage"] = "Account Created Successfully";
                    }
                }
            }


            return View();
        }
        private string HashPassword(string password)
        {
            using (SHA256 sha256Hash = SHA256.Create())
            {
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(password));

                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                return builder.ToString();
            }
        }
        [HttpGet]
        public ActionResult SignIn()
        {
            return View();
        }
        [HttpPost]
        public IActionResult SignIn(LoginModel lm)
        {
            using (SqlConnection con = new SqlConnection(connection))
            {
                con.Open();

                string sqlQuery = "SELECT Username, Password FROM Users WHERE Username = @Username AND Password = @Password";

                using (SqlCommand cmd = new SqlCommand(sqlQuery, con))
                {
                    cmd.Parameters.AddWithValue("@Username", lm.Username);
                    cmd.Parameters.AddWithValue("@Password", HashPassword(lm.Password));

                    using (SqlDataReader sdr = cmd.ExecuteReader())
                    {
                        if (sdr.Read())
                        {

                            string username = sdr["Username"].ToString();
                            string password = sdr["Password"].ToString();


                            if (username == "Admin1" && password == HashPassword("admin1"))
                            {

                                HttpContext.Session.SetString("Username", lm.Username);
                                return RedirectToAction("AdminPage");
                            }
                            HttpContext.Session.SetString("Username", lm.Username);
                            return RedirectToAction("Index", "Home");
                        }
                        else
                        {
                            ModelState.AddModelError(string.Empty, "Invalid username or password.");
                        }
                    }
                }
            }
            return View(lm);
        }
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Index", "Home");
        }
        public IActionResult AdminPage()
        {
            // Logic for admin page
            return View();
        }

    }
}
