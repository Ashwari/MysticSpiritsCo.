﻿

using System.ComponentModel.DataAnnotations;

namespace MysticSpiritsCoUpdated.Models
{
    public class LoginModel
    {
        public int USER_ID { get; set; }

        [Display(Name = "Enter Username:")]
        [Required(ErrorMessage = "Username or Password is Invalid.")]
        public string Username { get; set; }

        [Display(Name = "Enter Password:")]
        [Required(ErrorMessage = "Username or Password is Invalid")]
        [DataType(DataType.Password)]
        public string Password { get; set; }


    }
}
