﻿using System.ComponentModel.DataAnnotations;

namespace MysticSpiritsCoUpdated.Models
{
    public class UserModel
    {
        public int USER_ID { get; set; }

        [Display(Name = "Enter Username:")]
        [Required(ErrorMessage = "Username is Required.")]
        public string Username { get; set; }

        [Display(Name = "Enter Email:")]
        [Required(ErrorMessage = "Email is Required.")]
        public string Email { get; set; }

        [Display(Name = "Enter Password:")]
        [StringLength(15, MinimumLength = 6)]
        [Required(ErrorMessage = "Password is Required.")]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        [DataType(DataType.Password)]
        [Display(Name = "Confirm Password:")]
        [Required(ErrorMessage = "Confirm Password is Required.")]
        [Compare("Password", ErrorMessage = "Please Re-enter Password Again")]
        public string ConfirmPassword { get; set; }
    }
}
