﻿using System.ComponentModel.DataAnnotations;

namespace MysticSpiritsCoUpdated.Models
{
	public class BookingModel
	{
		public int Booking_ID { get; set; }

		[Display(Name = "Enter Name:")]
		[Required(ErrorMessage = "Full Name is Required.")]
		public string Username { get; set; }

		[Display(Name = "Enter Email:")]
		[Required(ErrorMessage = "Email is Required.")]
		[DataType(DataType.EmailAddress)]
		public string Email { get; set; }

		[Display(Name = "Enter Phone Number:")]
		[Required(ErrorMessage = "Phone number is Required")]
		[DataType(DataType.PhoneNumber)]
		public string PhoneNumber { get; set; }

		[Display(Name = "Choose Experience:")]
		[Required(ErrorMessage = "Experience is Required.")]
		public string BookingExperience { get; set; }

		[Display(Name = "Number of Guests:")]
		[Required(ErrorMessage = "Number of Guests is Required.")]
		public string NumberOfGuests { get; set; }

		[Display(Name = "Booking Date:")]
		[Required(ErrorMessage = "Booking Date is Required.")]
		public DateTime BookingDate { get; set; }

		[Display(Name = "Booking Time:")]
		[Required(ErrorMessage = "Booking Time is Required.")]
		public TimeSpan BookingTime { get; set; }

      

    }
}
