﻿using System.ComponentModel.DataAnnotations;

namespace MysticSpiritsCoUpdated.Models
{
    public class BookingDisplayModel
    {

            public int Booking_ID { get; set; }

            [Display(Name = "Name:")]
             public string Username { get; set; }
            [Display(Name = "Email:")]
            public string Email { get; set; }

            [Display(Name = "Phone Number:")]
            public string PhoneNumber { get; set; }

            [Display(Name = "Booking Experience:")]
            public string BookingExperience { get; set; }
            [Display(Name = "Number Of Guests:")]
            public string NumberOfGuests { get; set; }
            [Display(Name = "Booking Date:")]
            public DateTime BookingDate { get; set; }
            [Display(Name = "Booking Time:")]
            public TimeSpan BookingTime { get; set; }

            public List<BookingDisplayModel> UserBookings { get; set; }

        }
    }
